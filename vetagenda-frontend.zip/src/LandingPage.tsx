import { useCallback, useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { HeroSearch } from './components/HeroSearch';
import { ClientAccessModal } from './components/ClientAccessModal';
import { MockRoleSwitcher, type DemoProfile } from './components/MockRoleSwitcher';
import { Navbar } from './components/Navbar';
import { PortalsGrid } from './components/PortalsGrid';
import { Footer } from './components/Footer';
import { Icon, type IconName } from './components/Icon';
import { FaqSection, HowItWorks } from './components/LandingSections';
import { Reveal } from './components/Reveal';
import {
  getCurrentVeterinarian,
  listServices,
  loginVeterinarianDemo,
  saveVeterinarianSession,
  type CatalogService,
} from './services/api';

const serviceVisuals = [
  'bg-[#E8F4F1] text-[#0D5C75]',
  'bg-[#F0F7F7] text-[#0F766E]',
  'bg-[#EEF2F7] text-[#475569]',
  'bg-[#F4F5F7] text-[#475569]',
];

const featuredServiceSpecs: { name: string; description: string; matches: string[]; icon: IconName }[] = [
  {
    name: 'Consulta general',
    description: 'Valoración clínica para acompañar el bienestar de tu mascota.',
    matches: ['consulta'],
    icon: 'stethoscope',
  },
  {
    name: 'Vacunación',
    description: 'Protección preventiva de acuerdo con su esquema de salud.',
    matches: ['vacun'],
    icon: 'syringe',
  },
  {
    name: 'Profilaxis',
    description: 'Atención preventiva para mantener la salud oral.',
    matches: ['profilaxis', 'dental', 'odont'],
    icon: 'tooth',
  },
  {
    name: 'Control',
    description: 'Seguimiento clínico para acompañar su recuperación y bienestar.',
    matches: ['control'],
    icon: 'heart',
  },
];

function normalizeServiceName(name: string) {
  return name.toLocaleLowerCase('es-CO').normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

function getServiceIcon(name: string, index: number): IconName {
  const normalizedName = normalizeServiceName(name);
  if (normalizedName.includes('vacun')) return 'syringe';
  if (normalizedName.includes('dental') || normalizedName.includes('odont') || normalizedName.includes('profilaxis')) return 'tooth';
  if (normalizedName.includes('consulta')) return 'stethoscope';
  if (normalizedName.includes('control')) return 'heart';
  return (['stethoscope', 'syringe', 'tooth', 'heart'] as IconName[])[index % 4];
}

function formatServiceDuration(service: CatalogService) {
  return service.duracionMinutos ? `${service.duracionMinutos} min` : 'Duración por confirmar';
}

function LandingPage() {
  const navigate = useNavigate();
  const [isLoginOpen, setIsLoginOpen] = useState(false);
  const [isClientAccessOpen, setIsClientAccessOpen] = useState(false);
  const [preferredRole, setPreferredRole] = useState<DemoProfile['rol'] | null>(null);
  const [catalogServices, setCatalogServices] = useState<CatalogService[]>([]);
  const [isCatalogLoading, setIsCatalogLoading] = useState(true);
  const [demoError, setDemoError] = useState<string | null>(null);
  const closeLogin = useCallback(() => setIsLoginOpen(false), []);

  useEffect(() => {
    let isMounted = true;
    listServices()
      .then((services) => {
        if (isMounted) setCatalogServices(services);
      })
      .catch(() => {
        if (isMounted) setCatalogServices([]);
      })
      .finally(() => {
        if (isMounted) setIsCatalogLoading(false);
      });

    return () => {
      isMounted = false;
    };
  }, []);

  async function startDemo(profile: DemoProfile) {
    if (profile.rol !== 'VETERINARIO') return;
    setDemoError(null);
    try {
      const auth = await loginVeterinarianDemo();
      const veterinarian = await getCurrentVeterinarian(auth.token);
      saveVeterinarianSession(veterinarian, auth.token);
      closeLogin();
      navigate(profile.destination);
    } catch (error) {
      closeLogin();
      setDemoError(error instanceof Error ? error.message : 'No fue posible iniciar el perfil demo.');
    }
  }

  return (
    <main id="main-content" tabIndex={-1} className="min-h-screen bg-white text-slate-900 focus:outline-none">
      <Navbar onOpenRoleSwitcher={() => {
        setIsClientAccessOpen(true);
      }} />

      {demoError && (
        <div
          role="alert"
          aria-live="assertive"
          className="mx-auto mt-4 flex max-w-4xl items-center justify-between gap-3 rounded-2xl border border-rose-300 bg-rose-50 px-5 py-3 text-sm font-medium text-rose-900"
        >
          <span>⚠️ {demoError}</span>
          <button
            type="button"
            aria-label="Cerrar aviso de error"
            onClick={() => setDemoError(null)}
            className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl font-bold text-rose-900 transition hover:bg-rose-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0D5C75]"
          >
            ×
          </button>
        </div>
      )}

      <HeroSearch services={catalogServices} isLoading={isCatalogLoading} />

      <HowItWorks />

      <section id="servicios" className="scroll-mt-28 bg-[#F0F7F7] px-5 py-16 md:px-10 md:py-24">
        <div className="mx-auto max-w-7xl">
          <div className="mb-9 flex flex-col justify-between gap-4 sm:flex-row sm:items-end">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#0D5C75]">Servicios clínicos</p>
              <h2 className="mt-3 max-w-2xl text-3xl font-bold tracking-tight text-slate-900 md:text-4xl">
                Atención profesional para cada necesidad.
              </h2>
            </div>
            <p className="max-w-md text-sm leading-6 text-slate-600">
              Estos valores son referenciales. Consulta el catálogo para conocer las opciones de atención disponibles.
            </p>
          </div>

          <div className="grid gap-5 sm:grid-cols-2 xl:grid-cols-4">
            {featuredServiceSpecs.map((spec, index) => {
              const service = catalogServices.find((item) => {
                const name = normalizeServiceName(item.nombre);
                return spec.matches.some((match) => name.includes(match));
              });

              return (
              <Reveal key={spec.name} delay={index * 100}>
              <article
                className="h-full rounded-3xl border border-slate-200 bg-white p-4 shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl hover:shadow-slate-200/50"
              >
                <div className={`flex h-36 items-center justify-center rounded-2xl ${serviceVisuals[index % serviceVisuals.length]}`} aria-hidden="true">
                  <Icon name={service ? getServiceIcon(service.nombre, index) : spec.icon} className="h-16 w-16" />
                </div>
                <h3 className="mt-5 text-lg font-bold text-slate-900">{service?.nombre ?? spec.name}</h3>
                <p className="mt-2 min-h-12 text-sm leading-6 text-slate-600">{service?.descripcion ?? spec.description}</p>
                <div className="mt-5 flex items-center justify-between border-t border-slate-100 pt-4 text-sm">
                  <span className="text-slate-600">{service ? formatServiceDuration(service) : 'Por confirmar'}</span>
                  <span className="font-bold text-[#0D5C75]">{service?.precio ?? 'Consultar'}</span>
                </div>
                {!service && <p className="mt-3 text-xs font-medium text-slate-600">Consulta disponibilidad en la clínica.</p>}
              </article>
              </Reveal>
              );
            })}
          </div>
          <div className="mt-8 text-center">
            <Link to="/catalogo" className="inline-flex min-h-[44px] items-center justify-center rounded-full border border-[#0D5C75] px-5 py-2.5 text-sm font-bold text-[#0D5C75] transition hover:bg-[#E8F4F1] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0D5C75] focus-visible:ring-offset-2">
              Ver catálogo completo
            </Link>
          </div>
        </div>
      </section>

      <PortalsGrid onOpenDemo={(role) => {
        if (role === 'CLIENTE') {
          setIsClientAccessOpen(true);
          return;
        }
        setPreferredRole(role);
        setIsLoginOpen(true);
      }} />

      <FaqSection />

      <Footer />

      <MockRoleSwitcher
        isOpen={isLoginOpen}
        onClose={closeLogin}
        onSwitchRole={startDemo}
        preferredRole={preferredRole}
      />
      <ClientAccessModal
        isOpen={isClientAccessOpen}
        onClose={() => setIsClientAccessOpen(false)}
      />
    </main>
  );
}

export default LandingPage;
