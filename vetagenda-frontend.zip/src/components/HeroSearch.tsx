import { useEffect, useMemo, useState, type FormEvent } from 'react';
import { useNavigate } from 'react-router-dom';
import { fetchCatalogo, getClinicTodayDate, type CatalogService, type VeterinarioConServicios } from '../services/api';
import { Icon } from './Icon';

const anyVeterinarianOption = { value: 'all', label: 'Cualquier profesional' };

function normalizeText(value: string) {
  return value.toLocaleLowerCase('es-CO').normalize('NFD').replace(/[\u0300-\u036f]/g, '').trim();
}

function getTodayDate() {
  return getClinicTodayDate();
}

type HeroSearchProps = {
  services: CatalogService[];
  isLoading: boolean;
};

export function HeroSearch({ services, isLoading }: HeroSearchProps) {
  const navigate = useNavigate();
  const [service, setService] = useState('');
  const [catalog, setCatalog] = useState<VeterinarioConServicios[]>([]);
  const [veterinarian, setVeterinarian] = useState(anyVeterinarianOption.value);
  const [date, setDate] = useState(getTodayDate);

  useEffect(() => {
    let isMounted = true;
    fetchCatalogo()
      .then((vets) => {
        if (isMounted) setCatalog(vets);
      })
      .catch(() => {
        if (isMounted) setCatalog([]);
      });
    return () => {
      isMounted = false;
    };
  }, []);

  useEffect(() => {
    if (!service && services.length > 0) {
      setService(String(services[0].id));
    }
  }, [service, services]);

  const selectedService = services.find((item) => String(item.id) === service);
  const vetOptions = useMemo(() => {
    if (!selectedService) return [anyVeterinarianOption];

    const matchingVets = catalog.filter((vet) => vet.servicios.some((item) => (
      String(item.id) === service || normalizeText(item.nombre) === normalizeText(selectedService.nombre)
    )));

    return [
      anyVeterinarianOption,
      ...matchingVets.map((vet) => ({ value: String(vet.id), label: vet.nombre })),
    ];
  }, [catalog, selectedService, service]);

  useEffect(() => {
    if (!vetOptions.some((option) => option.value === veterinarian)) {
      setVeterinarian(anyVeterinarianOption.value);
    }
  }, [veterinarian, vetOptions]);

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const query = new URLSearchParams({ servicio: service, veterinario: veterinarian, fecha: date });
    navigate(`/disponibilidad?${query.toString()}`);
  }

  return (
    <section className="overflow-hidden bg-[linear-gradient(180deg,#F0F7F7_0%,#FFFFFF_100%)] px-5 pb-16 pt-12 md:px-10 md:pb-24 md:pt-16">
      <div className="mx-auto grid max-w-7xl items-center gap-9 lg:grid-cols-[1.1fr_0.9fr] lg:gap-12">
        <div>
          <div className="inline-flex items-center gap-2 rounded-full bg-[#E8F4F1] px-4 py-2 text-xs font-bold text-[#0D5C75]">
            <Icon name="sparkle" className="h-4 w-4 text-[#0D9488]" filled />
            Gestión veterinaria ágil y humana
          </div>
          <h1 className="mt-6 max-w-2xl text-4xl font-black leading-[1.08] tracking-tight text-slate-900 sm:text-5xl lg:text-[3.7rem]">
            El cuidado de tu mascota,
            <span className="block text-[#0D5C75]">más ágil y humano.</span>
          </h1>
          <p className="mt-5 max-w-2xl text-base leading-7 text-slate-600 sm:text-lg sm:leading-8">
            Organiza citas, disponibilidad asistencial y el cuidado de tus mascotas en un solo lugar.
          </p>

          <form
            onSubmit={handleSubmit}
            className="mt-8 grid grid-cols-1 gap-3 rounded-3xl border border-slate-200 bg-white p-4 shadow-xl shadow-slate-200/50 sm:grid-cols-2"
          >
            <div className="min-w-0 px-2 py-1">
              <label htmlFor="hero-service-select" className="mb-1.5 block text-xs font-extrabold uppercase tracking-[0.12em] text-slate-600">
                Especialidad o servicio
              </label>
              <select
                id="hero-service-select"
                required
                disabled={isLoading || services.length === 0}
                value={service || String(services[0]?.id ?? '')}
                onChange={(event) => {
                  setService(event.target.value);
                  setVeterinarian(anyVeterinarianOption.value);
                }}
                className="min-h-[44px] w-full rounded-lg border-0 bg-white px-1 py-2 text-sm font-semibold text-slate-800 outline-none focus-visible:ring-2 focus-visible:ring-[#0D5C75]"
              >
                {isLoading && <option value="">Cargando servicios...</option>}
                {!isLoading && services.length === 0 && <option value="">No hay servicios disponibles</option>}
                {services.map((option) => <option key={option.id} value={option.id}>{option.nombre}</option>)}
              </select>
            </div>

            <div className="min-w-0 border-t border-slate-100 px-2 py-3 sm:border-l sm:border-t-0 sm:py-1">
              <label htmlFor="hero-vet-select" className="mb-1.5 block text-xs font-extrabold uppercase tracking-[0.12em] text-slate-600">
                Veterinario
              </label>
              <select
                id="hero-vet-select"
                value={veterinarian}
                onChange={(event) => setVeterinarian(event.target.value)}
                className="min-h-[44px] w-full rounded-lg border-0 bg-white px-1 py-2 text-sm font-semibold text-slate-800 outline-none focus-visible:ring-2 focus-visible:ring-[#0D5C75]"
              >
                {vetOptions.map((option) => <option key={option.value} value={option.value}>{option.label}</option>)}
              </select>
            </div>

            <div className="min-w-0 border-t border-slate-100 px-2 py-3 sm:col-span-2">
              <label htmlFor="hero-date-input" className="mb-1.5 block text-xs font-extrabold uppercase tracking-[0.12em] text-slate-600">
                Fecha deseada
              </label>
              <input
                id="hero-date-input"
                type="date"
                min={getTodayDate()}
                value={date}
                onChange={(event) => setDate(event.target.value)}
                required
                className="min-h-[44px] w-full rounded-lg border-0 bg-white px-1 py-2 text-sm font-semibold text-slate-800 outline-none focus-visible:ring-2 focus-visible:ring-[#0D5C75]"
              />
            </div>

            <button
              type="submit"
              disabled={isLoading || services.length === 0}
              className="min-h-[48px] w-full rounded-full bg-[#0D5C75] px-5 text-sm font-bold text-white transition-all duration-300 hover:-translate-y-0.5 hover:bg-[#094356] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0D5C75] focus-visible:ring-offset-2 sm:col-span-2"
            >
              {isLoading ? 'Cargando servicios...' : 'Buscar horarios'}
            </button>
          </form>
        </div>

        <div className="relative mx-auto w-full max-w-[560px]">
          <div className="absolute -bottom-5 -left-4 h-32 w-32 rounded-full bg-[#E8F4F1]" aria-hidden="true" />
          <div className="absolute -right-4 -top-5 h-28 w-28 rounded-full bg-[#d9eeeb]" aria-hidden="true" />
          <div className="relative aspect-[1.12] overflow-hidden rounded-3xl bg-slate-100 shadow-xl shadow-slate-200/50">
            <img
              src="https://images.pexels.com/photos/7474851/pexels-photo-7474851.jpeg?auto=compress&w=1200"
              alt="Equipo veterinario atiende a un perro dorado en una clínica"
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-x-4 bottom-4 rounded-2xl border border-white/60 bg-white/95 p-4 shadow-lg backdrop-blur sm:inset-x-6 sm:bottom-6 sm:p-5">
              <p className="text-xs font-bold uppercase tracking-[0.15em] text-[#0F766E]">Cuidado en cada etapa</p>
              <p className="mt-1 text-base font-bold text-slate-900 sm:text-lg">Tu mascota, en buenas manos.</p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
