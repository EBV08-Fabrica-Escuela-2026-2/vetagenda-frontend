import { useEffect, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import { AppointmentStatusBadge } from '../components/AppointmentStatusBadge';
import { BackToHomeButton } from '../components/BackToHomeButton';
import { BrandHeader } from '../components/BrandHeader';
import { ClientSessionActions } from '../components/ClientSessionActions';
import {
  cancelVeterinarianAppointment,
  getVeterinarianSession,
  listVeterinarianAppointments,
  type VeterinarianAppointmentApi,
} from '../services/api';
import { useModalAccessibility } from '../utils/useModalAccessibility';

const MIN_REASON_LENGTH = 10;

type AppointmentStatus = 'Programada' | 'Completada' | 'Cancelada';

type Appointment = {
  id: number;
  client: string;
  pet: string;
  service: string;
  date: string;
  time: string;
  status: AppointmentStatus;
  cancellationReason?: string;
};

function mapAppointment(item: VeterinarianAppointmentApi): Appointment {
  const status: AppointmentStatus = item.estado === 'CONFIRMADA'
    ? 'Programada'
    : item.estado === 'COMPLETADA'
      ? 'Completada'
      : 'Cancelada';
  const petDetails = [item.mascotaNombre, item.mascotaEspecie, item.mascotaRaza].filter(Boolean).join(' · ');
  return {
    id: item.id,
    client: item.clienteNombre,
    pet: petDetails,
    service: item.servicioNombre,
    date: item.fechaHoraInicio,
    time: new Intl.DateTimeFormat('es-CO', { hour: 'numeric', minute: '2-digit' }).format(new Date(item.fechaHoraInicio)),
    status,
    cancellationReason: item.motivoCancelacion,
  };
}

function formatAppointmentDate(value: string) {
  return new Intl.DateTimeFormat('es-CO', {
    weekday: 'long',
    day: 'numeric',
    month: 'long',
    year: 'numeric',
  }).format(new Date(value));
}

type CancellationDialogProps = {
  appointment: Appointment;
  onClose: () => void;
  onConfirm: (appointmentId: number, reason: string) => void;
};

function CancellationDialog({ appointment, onClose, onConfirm }: CancellationDialogProps) {
  const [reason, setReason] = useState('');
  const dialogRef = useRef<HTMLElement>(null);
  const textareaRef = useRef<HTMLTextAreaElement>(null);
  const normalizedReason = reason.trim();
  const isReasonValid = normalizedReason.length >= MIN_REASON_LENGTH;
  const hasValidationError = reason.length > 0 && !isReasonValid;

  useModalAccessibility({
    isOpen: true,
    onClose,
    dialogRef,
    initialFocusRef: textareaRef,
  });

  function handleSubmit(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!isReasonValid) return;
    onConfirm(appointment.id, normalizedReason);
  }

  return (
    <div
      className="fixed inset-0 z-50 flex items-center justify-center overflow-y-auto bg-slate-950/50 p-4 backdrop-blur-sm"
      onMouseDown={(event) => {
        if (event.target === event.currentTarget) onClose();
      }}
    >
      <section
        ref={dialogRef}
        tabIndex={-1}
        aria-labelledby="cancel-dialog-title"
        aria-modal="true"
        className="my-auto w-full max-w-lg rounded-3xl bg-white p-6 shadow-2xl outline-none sm:p-8"
        role="dialog"
      >
        <div className="flex items-start justify-between gap-4">
          <div>
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-rose-700">Acción definitiva</p>
            <h2 id="cancel-dialog-title" className="mt-2 text-2xl font-black text-slate-900">
              Cancelar cita
            </h2>
          </div>
          <button
            type="button"
            aria-label="Cerrar ventana de cancelación"
            onClick={onClose}
            className="flex h-11 w-11 min-h-[44px] min-w-[44px] shrink-0 items-center justify-center rounded-xl text-xl text-slate-600 transition hover:bg-slate-100 hover:text-slate-900 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0D5C75]"
          >
            ×
          </button>
        </div>

        <div className="mt-5 rounded-2xl bg-slate-50 p-4">
          <p className="font-bold text-slate-900">{appointment.client} · {appointment.pet}</p>
          <p className="mt-1 text-sm text-slate-700">{appointment.service}</p>
          <p className="mt-2 text-sm font-semibold capitalize text-slate-700">
            {formatAppointmentDate(appointment.date)} · {appointment.time}
          </p>
        </div>

        <form className="mt-5" onSubmit={handleSubmit}>
          <label htmlFor="cancellation-reason" className="block text-sm font-bold text-slate-800">
            Motivo de cancelación <span className="text-rose-700">*</span>
          </label>
          <p id="reason-help" className="mt-1 text-sm text-slate-600">
            Explica brevemente por qué debes cancelar. Mínimo {MIN_REASON_LENGTH} caracteres.
          </p>
          <textarea
            ref={textareaRef}
            id="cancellation-reason"
            aria-describedby={hasValidationError ? 'reason-help reason-counter reason-error' : 'reason-help reason-counter'}
            aria-invalid={hasValidationError}
            maxLength={240}
            onChange={(event) => setReason(event.target.value)}
            placeholder="Escribe el motivo para informar al cliente..."
            required
            rows={4}
            value={reason}
            className="mt-3 w-full resize-y rounded-xl border border-slate-300 px-4 py-3 text-sm text-slate-800 outline-none transition placeholder:text-slate-500 focus:border-[#0D5C75] focus-visible:ring-2 focus-visible:ring-[#0D5C75]"
          />
          <div className="mt-2 flex items-start justify-between gap-3 text-xs">
            <span id="reason-counter" className={isReasonValid ? 'font-semibold text-emerald-800' : 'text-slate-600'}>
              {normalizedReason.length}/{MIN_REASON_LENGTH} caracteres mínimos
            </span>
            {hasValidationError && (
              <span id="reason-error" role="alert" className="text-right font-semibold text-rose-700">
                El motivo debe tener al menos {MIN_REASON_LENGTH} caracteres.
              </span>
            )}
          </div>

          <div className="mt-6 flex flex-col-reverse gap-3 sm:flex-row sm:justify-end">
            <button
              type="button"
              onClick={onClose}
              className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-slate-300 px-5 py-3 text-sm font-semibold text-slate-700 transition hover:bg-slate-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0D5C75] focus-visible:ring-offset-1"
            >
              Volver
            </button>
            <button
              type="submit"
              disabled={!isReasonValid}
              className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl bg-rose-700 px-5 py-3 text-sm font-bold text-white transition hover:bg-rose-800 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0D5C75] focus-visible:ring-offset-1 disabled:cursor-not-allowed disabled:bg-slate-300 disabled:text-slate-700"
            >
              Confirmar cancelación
            </button>
          </div>
        </form>
      </section>
    </div>
  );
}

export function VeterinarianAppointmentsPage() {
  const [appointments, setAppointments] = useState<Appointment[]>([]);
  const [selectedAppointment, setSelectedAppointment] = useState<Appointment | null>(null);
  const [notification, setNotification] = useState<string | null>(null);
  const [showAll, setShowAll] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [loadError, setLoadError] = useState<string | null>(null);
  const veterinarian = getVeterinarianSession();

  useEffect(() => {
    let active = true;
    listVeterinarianAppointments()
      .then((items) => {
        if (active) setAppointments(items.map(mapAppointment));
      })
      .catch((error) => {
        if (active) setLoadError(error instanceof Error ? error.message : 'No fue posible cargar la agenda.');
      })
      .finally(() => {
        if (active) setIsLoading(false);
      });
    return () => { active = false; };
  }, []);

  const orderedAppointments = [...appointments].sort(
    (left, right) => new Date(left.date).getTime() - new Date(right.date).getTime(),
  );
  const visibleAppointments = showAll
    ? orderedAppointments
    : orderedAppointments.filter((appointment) => appointment.status === 'Programada');
  const pendingCount = appointments.filter((appointment) => appointment.status === 'Programada').length;

  async function cancelAppointment(appointmentId: number, reason: string) {
    const appointment = appointments.find((item) => item.id === appointmentId);
    if (!appointment || appointment.status !== 'Programada') return;
    try {
      await cancelVeterinarianAppointment(appointmentId, reason);
      setAppointments((current) => current.map((item) => item.id === appointmentId
        ? { ...item, status: 'Cancelada', cancellationReason: reason }
        : item));
      setSelectedAppointment(null);
      setNotification(`La cita de ${appointment.client} fue cancelada y el horario ${appointment.time} quedó liberado.`);
    } catch (error) {
      setSelectedAppointment(null);
      setNotification(error instanceof Error ? error.message : 'No fue posible cancelar la cita.');
    }
  }

  return (
    <main id="main-content" tabIndex={-1} className="min-h-screen bg-sky-50 px-4 py-8 text-slate-800 md:px-8">
      <div className="mx-auto max-w-6xl">
        <header className="mb-6 flex flex-col gap-4 rounded-3xl bg-white p-6 shadow-sm ring-1 ring-slate-200 sm:flex-row sm:items-center sm:justify-between">
          <BrandHeader subtitle="Agenda del veterinario" />
          <div className="flex flex-wrap items-center justify-end gap-3">
            <Link
              to="/veterinario/disponibilidad"
              className="inline-flex min-h-[44px] items-center gap-2 rounded-xl border border-sky-200 bg-sky-50 px-4 py-2 text-sm font-bold text-sky-900 transition hover:bg-sky-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0D5C75] focus-visible:ring-offset-1"
            >
              <span aria-hidden="true">⏰</span>
              <span>Gestionar disponibilidad</span>
            </Link>
            <ClientSessionActions showPortalLink={false} />
            <BackToHomeButton />
          </div>
        </header>

        <section className="mb-6 flex flex-col gap-5 rounded-3xl bg-gradient-to-r from-[#0D5C75] to-cyan-800 p-6 text-white shadow-lg sm:flex-row sm:items-center sm:justify-between sm:p-8">
          <div>
            <p className="text-sm font-semibold text-sky-100">Panel profesional · {veterinarian?.nombre}</p>
            <h1 className="mt-2 text-3xl font-black">Mi agenda</h1>
            <p className="mt-2 max-w-xl text-sm text-sky-50">
              Revisa tus citas programadas, gestiona cancelaciones y administra tus horarios de atención disponibles.
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <Link
              to="/veterinario/disponibilidad"
              className="inline-flex min-h-[44px] items-center gap-2 rounded-2xl bg-white px-5 py-3 text-sm font-bold text-[#0D5C75] shadow-sm transition hover:bg-sky-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-white focus-visible:ring-offset-2 focus-visible:ring-offset-[#0D5C75]"
            >
              <span aria-hidden="true">⏰</span>
              <span>Gestionar disponibilidad</span>
            </Link>
            <div className="rounded-2xl bg-white/15 px-5 py-3 text-center ring-1 ring-white/25">
              <p className="text-xs text-sky-50">Citas pendientes</p>
              <p className="mt-0.5 text-2xl font-black">{pendingCount}</p>
            </div>
          </div>
        </section>

        <div className="mb-6 flex flex-wrap gap-2 border-b border-slate-200 pb-2">
          <button
            type="button"
            aria-current="page"
            className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-[#0D5C75] px-4 py-2.5 text-sm font-bold text-white shadow-sm focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0D5C75] focus-visible:ring-offset-2"
          >
            <span aria-hidden="true">📅</span>
            <span>Citas agendadas</span>
            <span className="ml-1 rounded-full bg-sky-900 px-2 py-0.5 text-xs text-sky-100">{pendingCount}</span>
          </button>
          <Link
            to="/veterinario/disponibilidad"
            className="inline-flex min-h-[44px] items-center gap-2 rounded-xl bg-white px-4 py-2.5 text-sm font-semibold text-slate-700 ring-1 ring-slate-200 transition hover:bg-slate-50 hover:text-[#0D5C75] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0D5C75] focus-visible:ring-offset-1"
          >
            <span aria-hidden="true">⏰</span>
            <span>Gestionar disponibilidad</span>
          </Link>
        </div>

        <section className="rounded-3xl bg-white p-5 shadow-sm ring-1 ring-slate-200 md:p-7">
          <div className="flex flex-col gap-4 border-b border-slate-100 pb-5 sm:flex-row sm:items-end sm:justify-between">
            <div>
              <p className="text-xs font-bold uppercase tracking-[0.2em] text-[#0D5C75]">Citas del profesional</p>
              <h2 className="mt-2 text-2xl font-black text-slate-900">Agenda de atención</h2>
            </div>
            <label
              htmlFor="show-all-appointments"
              className="inline-flex min-h-[44px] cursor-pointer items-center gap-2.5 rounded-xl px-2 text-sm font-semibold text-slate-700"
            >
              <input
                id="show-all-appointments"
                type="checkbox"
                checked={showAll}
                onChange={(event) => setShowAll(event.target.checked)}
                className="h-5 w-5 rounded border-slate-400 text-[#0D5C75] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0D5C75]"
              />
              <span>Mostrar historial</span>
            </label>
          </div>

          <div aria-live="polite">
            {notification && (
              <div role="status" className="mt-5 flex items-center gap-3 rounded-2xl border border-emerald-200 bg-emerald-50 p-4 text-sm text-emerald-950">
                <span aria-hidden="true" className="text-lg">✓</span>
                <p className="flex-1">{notification}</p>
                <button
                  type="button"
                  aria-label="Cerrar confirmación"
                  onClick={() => setNotification(null)}
                  className="ml-auto flex h-11 w-11 min-h-[44px] min-w-[44px] items-center justify-center rounded-xl font-bold text-emerald-900 hover:bg-emerald-100 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0D5C75]"
                >
                  ×
                </button>
              </div>
            )}
          </div>

          {isLoading ? (
            <div
              role="status"
              aria-live="polite"
              aria-busy="true"
              className="mt-6 grid gap-3"
              aria-label="Cargando agenda"
            >
              <span className="sr-only">Cargando agenda del veterinario...</span>
              {Array.from({ length: 3 }, (_, index) => <div key={index} className="h-28 animate-pulse rounded-2xl bg-slate-100" />)}
            </div>
          ) : loadError ? (
            <div role="alert" aria-live="assertive" className="mt-6 rounded-2xl border border-rose-200 bg-rose-50 p-5 text-sm font-semibold text-rose-900">
              {loadError}
            </div>
          ) : visibleAppointments.length === 0 ? (
            <div className="mt-6 rounded-2xl border border-dashed border-slate-300 bg-slate-50 px-5 py-12 text-center" role="status">
              <div className="mx-auto flex h-14 w-14 items-center justify-center rounded-full bg-white text-2xl shadow-sm" aria-hidden="true">🗓️</div>
              <h3 className="mt-4 text-lg font-bold text-slate-900">No hay citas para mostrar</h3>
              <p className="mt-1 text-sm text-slate-600">
                {showAll ? 'Todavía no hay citas registradas en la agenda.' : 'No tienes citas pendientes en este momento.'}
              </p>
            </div>
          ) : (
            <div className="mt-5 space-y-4">
              {visibleAppointments.map((appointment) => (
                <article key={appointment.id} className="rounded-2xl border border-slate-200 p-4 transition hover:border-sky-200 sm:p-5">
                  <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
                    <div className="flex gap-4">
                      <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-2xl bg-sky-50 text-xl" aria-hidden="true">🐾</div>
                      <div>
                        <div className="flex flex-wrap items-center gap-2">
                          <h3 className="font-bold text-slate-900">{appointment.client}</h3>
                          <AppointmentStatusBadge status={appointment.status} />
                        </div>
                        <p className="mt-1 text-sm text-slate-600">{appointment.pet}</p>
                        <p className="mt-2 text-sm font-semibold text-slate-800">{appointment.service}</p>
                        <p className="mt-1 text-sm capitalize text-slate-600">
                          {formatAppointmentDate(appointment.date)} · {appointment.time}
                        </p>
                        {appointment.cancellationReason && (
                          <p className="mt-2 text-sm text-rose-800">
                            <span className="font-semibold">Motivo:</span> {appointment.cancellationReason}
                          </p>
                        )}
                      </div>
                    </div>

                    {appointment.status === 'Programada' ? (
                      <button
                        type="button"
                        onClick={() => {
                          setNotification(null);
                          setSelectedAppointment(appointment);
                        }}
                        className="inline-flex min-h-[44px] min-w-[44px] items-center justify-center rounded-xl border border-rose-300 px-4 py-2.5 text-sm font-bold text-rose-800 transition hover:border-rose-400 hover:bg-rose-50 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[#0D5C75] focus-visible:ring-offset-1"
                      >
                        Cancelar cita
                      </button>
                    ) : (
                      <span className="text-xs font-semibold text-slate-600">
                        {appointment.status === 'Completada' ? 'Cita finalizada' : 'No se puede modificar'}
                      </span>
                    )}
                  </div>
                </article>
              ))}
            </div>
          )}
        </section>

        <p className="mt-5 text-center text-xs text-slate-600">
          Agenda sincronizada con VetAgenda. Los cambios se reflejan también en las citas del cliente.
        </p>
      </div>

      {selectedAppointment && (
        <CancellationDialog
          appointment={selectedAppointment}
          onClose={() => setSelectedAppointment(null)}
          onConfirm={cancelAppointment}
        />
      )}
    </main>
  );
}
